dict={}
high=int(input("Enter the number: "))
for i in range(1,high+1):
    dict[i]=i*i

print("The dictionary is: ")
print(dict)
