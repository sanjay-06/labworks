str=input("Enter the number: ")
n1=str
n2=str*2
n3=str*3
n4=str*4
value=int(n1)+int(n2)+int(n3)+int(n4)
print("The value is {}".format(value))
