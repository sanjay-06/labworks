set={2,3,4,1,5,10,6}
print("The set is {}".format(set))
print("The number of elements is {}".format(len(set)))
