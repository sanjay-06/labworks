set={2,3,4,1,5,10,6}
print("The set is {}".format(set))
set.clear()
print("The set after clear is {}".format(set))
