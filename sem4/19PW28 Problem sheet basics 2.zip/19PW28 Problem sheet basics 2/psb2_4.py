set={2,3,4,1,5,10,6}
print("The set is {}".format(set))
print("The maximum element is {}".format(max(set)))
print("The minimum element is {}".format(min(set)))
