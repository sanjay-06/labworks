list=[12,24,35,24,88,120,155]
newlist=[x for x in list if x!=24]
print(newlist)
